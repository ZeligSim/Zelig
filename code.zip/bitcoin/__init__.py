"""
This module extends the core simulator to implement a Bitcoin simulator.
"""