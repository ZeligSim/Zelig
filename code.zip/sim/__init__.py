"""
The `sim` module contains the core simulator.
"""